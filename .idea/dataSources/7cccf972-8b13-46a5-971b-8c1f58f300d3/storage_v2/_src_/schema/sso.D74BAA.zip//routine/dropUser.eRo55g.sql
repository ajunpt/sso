create procedure dropUser()
begin
    SET AUTOCOMMIT=0;

    delete from USER_AUTHORITY  where  exists (select  ID from USER u where USERNAME like '%test%' and u.ID=USER_ID);
    delete from USER where USERNAME like '%test%';
    commit;
  end;

