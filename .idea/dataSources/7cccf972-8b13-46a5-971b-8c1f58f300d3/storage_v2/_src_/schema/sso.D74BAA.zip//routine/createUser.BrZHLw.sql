create procedure createUser(IN param int)
begin
  declare i int default 1;
  declare rand1 int default 0;
  declare id int default 4;
  declare auth varchar(100) default null;
  SET AUTOCOMMIT=0;
  while i<=param do
  set rand1 = FLOOR(1 + RAND() * (6));
  insert into `USER`
  ( ID,ACCOUNTNONEXPIRED, ACCOUNTNONLOCKED, CREDENTIALSNONEXPIRED, EMAIL, ENABLE, INVALIDTIME, MOBILE, PASSWORD, USERNAME, VALIDTIME)
  VALUES
  (id,1,1,1,concat('test',id,'@test.com'),1,now(),'13115623357','',concat('test',id,'@test.com'),now());
  set auth = case rand1%5
    when 1 then 'ROLE_MODULEADMIN'
    when 2 then 'ROLE_SYSTEMADMIN'
    when 3 then 'ROLE_USER'
    when 4 then 'ROLE_VIP1'
    when 0 then 'ROLE_VIP2'
    end ;
  insert into USER_AUTHORITY
  (USER_ID, AUTHORITY_ID)
  values
  (id,auth);
  set i = i+1;
  set id=id+1;
  end while;
  commit;
end;

